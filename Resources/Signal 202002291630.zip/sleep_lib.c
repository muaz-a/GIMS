#include "sleep_lib.h"
#include "lib387.h"


void sleep(void){
    /*
    //turn off DAC and ADC
    DAC->CR &= ~(DAC_CR_EN1 | DAC_CR_EN2);
    ADC1->CR2 &= ~ADC_CR2_ADON;
    ADC2->CR2 &= ~ADC_CR2_ADON;
    */
    
    SCB->SCR |= SCB_SCR_SLEEPDEEP;
    PWR->CR &= ~PWR_CR_PDDS; //set to stop mode
    PWR->CR |= PWR_CR_LPDS; //set low power mode
    PWR->CR |= PWR_CR_CWUF; //clear WUF
    EXTI8Init();
    EXTI->PR |= EXTI_PR_PR8;	//clear interrupt
    Configure_RTC();
    __WFI();
    
    EXTI8Dis();
    NVIC_DisableIRQ(RTC_IRQn);
    clockInit();
    
}

void Configure_RTC(void)
{
  /* Enable the peripheral clock RTC */
  /* (1) Enable the LSI */
  /* (2) Wait while it is not ready */
  /* (3) Enable PWR clock */
  /* (4) Enable write in RTC domain control register */
  /* (5) LSI for RTC clock */
  /* (6) Disable PWR clock */
  RCC->CSR |= RCC_CSR_LSION; /* (1) */
  while((RCC->CSR & RCC_CSR_LSIRDY)!=RCC_CSR_LSIRDY) /* (2) */
  {
    /* add time out here for a robust application */
  }
  RCC->APB1ENR |= RCC_APB1ENR_PWREN; /* (3) */
  PWR->CR |= PWR_CR_DBP; /* (4) */
  RCC->BDCR = (RCC->BDCR & ~RCC_BDCR_RTCSEL) | RCC_BDCR_RTCEN | RCC_BDCR_RTCSEL_1; /* (5) */
  RCC->APB1ENR &=~ RCC_APB1ENR_PWREN; /* (7) */

  /* Configure RTC */
  /* (7) Write access for RTC regsiters */
  /* (8) Disable wake up timerto modify it */
  /* (9) Wait until it is allow to modify wake up reload value */
  /* (10) Modify wake upvalue reload counter to have a wake up each 1Hz */
  /* (11) Enable wake up counter and wake up interrupt */
  /* (12) Disable write access */
  RTC->CRL |= RTC_CRL_CNF; /* (7) */
  RTC->CRH &=~ RTC_CRH_ALRIE; /* (8) */
  while((RTC->CRL & RTC_CRL_RTOFF) != RTC_CRL_RTOFF) /* (9) */
  {
    /* add time out here for a robust application */
  }
  RTC->PRLH = 0x4; //30s (32768*30)-1 = 0xEFFFF (10s=x4FFF)
    RTC->PRLL = 0xFFFF; /* (10) */
  RTC->CNTL = 0;
    RTC->CNTH = 0;
  RTC->CRH |= RTC_CRH_ALRIE; /* (11) */
    RTC->CRL &= ~RTC_CRL_CNF; /* (12) */
 
  /* Configure exti and nvic for RTC IT */
  /* (13) unmask line 20 */
  /* (14) Rising edge for line 20 */
  /* (15) Set priority */
  /* (16) Enable RTC_IRQn */
  EXTI->IMR |= EXTI_IMR_MR17; /* (13) */
  EXTI->RTSR |= EXTI_RTSR_TR17; /* (14) */
  NVIC_SetPriority(RTC_IRQn, 0); /* (15) */
  NVIC_EnableIRQ(RTC_IRQn); /* (16) */

}
