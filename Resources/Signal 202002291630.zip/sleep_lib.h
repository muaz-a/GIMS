#ifndef SLEEP_LIB_H
#define SLEEP_LIB_H

#include "stm32f10x.h"

void sleep(void);
void Configure_RTC(void);

#endif
