#include "stm32f10x.h"
#include "sleep_lib.h"
#include "lib387.h"
#include "sin.h"

void led_wigwag(void);

extern volatile int reset;
extern int sinScale;
extern volatile uint16_t error;
extern volatile uint8_t timer;


int main(void)
{
    //clockInit();  //Sets up the processor clock to run at 24MHz
    butInit();
    ledGBInit();
    ledInit();
    
    reset = 1;
    sinScale = 1;
    clockInit();
    //sysTickInit(24e6);
    //while(1);
    idle();
}

void EXTI9_5_IRQHandler (void)
{
    if(EXTI->PR&EXTI_PR_PR8) {
        EXTI->PR |= EXTI_PR_PR8;
        if (reset) {
            reset = 0;
            sinScale = 1;
        }
    }
    else if (EXTI->PR&EXTI_PR_PR9) {
        EXTI->PR |= EXTI_PR_PR9;
        if (reset) {
            reset = 0;
            sinScale = 2;
        }
    }
}

void TIM6_DAC_IRQHandler(void)
{
  
  if ((DAC->SR & DAC_SR_DMAUDR1) != 0) /* Test if transfer error on DMA and DAC channel 1 */
  {
    error |= ERROR_DAC_DMA_UNDERRUN; /* Report an error on DMA underrun */
    DAC->SR |= DAC_SR_DMAUDR1;
  }
  else
  {
    error |= ERROR_UNEXPECTED_DAC_IT; /* Report unexpected DMA interrupt occurrence */
  }
}


void SysTick_Handler(void)
{
    timer = 1;
    GPIOC->ODR ^= GPIO_ODR_ODR8;
}

 void EXTI0_IRQHandler (void){
	EXTI->PR |= EXTI_PR_PR0;
	GPIOC->ODR ^= GPIO_ODR_ODR9;
    
 }

void RTC_IRQHandler(void)
{
  /* Check WUT flag */
  if((RTC->CRL & (RTC_CRL_ALRF)) == (RTC_CRL_ALRF))
  {
    RTC->CRL &=~ RTC_CRL_ALRF; /* Reset Wake up flag */
    EXTI->PR |= EXTI_PR_PR17; /* clear exti line 20 flag */
    
  }
  else
  {
    NVIC_DisableIRQ(RTC_IRQn);/* Disable RTC_IRQn */
  }
  ledGBTog(BLUE_ON|GREEN_ON);
}
