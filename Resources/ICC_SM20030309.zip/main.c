#include <stdio.h>
#include <stdlib.h> 
#include "stm32f10x.h"
#include "lib387.h"
#include "sin.h"

#define MAXIN 30

typedef enum {
    STARTUP,
    SYNCH,
    LISTEN,
    TEST,
    RESPOND
} STATE;


typedef enum {
    ONLINE,
    TIMEOUT,
    NORMAL,
    ABNORMAL,
    REMOVED
} STATUS;

typedef struct {
    int index;
    int address;
    STATUS status;
} NODE;

volatile uint8_t alarm;

void led_wigwag(void);
void Startup(void);
int Synch(NODE*);
void Listen(int, NODE*);
void Test(int, NODE*);
void Respond(int, NODE*);

int main(void)
{
    int response = 0;
    int nodes = 0;
    NODE * status;
    STATE state = STARTUP;
    STATE nextState= state;
    
    clockInit();  //Sets up the processor clock to run at 24MHz
    ledGBInit();    //Generic Startup routine
    led_wigwag();   
    ledGBSet(GREEN_OFF|BLUE_OFF);
    
    while(1){
        switch (state) {
            
            case STARTUP:
                Startup();
                nextState = SYNCH;
                break;
            case SYNCH:
                nodes = Synch(status);
                nextState = LISTEN;
                break;
            case LISTEN:
                Listen(nodes, status);
                nextState = TEST;
                break;
            case TEST:
                Test(nodes, status);
                nextState = RESPOND;
                break;
            case RESPOND:
                Respond(nodes, status);
                nextState = LISTEN;
                break;
        }
        state = nextState;
    }
}

int Synch (NODE * status){
    int size = 0;
    int address = 0;
    int i = 0;
    status = malloc(size * sizeof(NODE));
    for(i=0;i<5;i++) {  //some loop to pole unknown amount
        //get id's of new nodes
        if (i==size) {
            realloc(status, sizeof(NODE)*(size+1));
        }
        status[i].index = i;
        status[i].address = i;
        status[i].status = ONLINE;
        size++;
    }
    return size;
}


void Listen(int size, NODE* node){
    int i=0, j=0;
    unsigned char input;
    
    usartInit();
    for (i = 0; i<size; i++) {
        uin(&input);    //wait for an input
        //process input
        sine(1);
        alarm = 0;
        Configure_RTC(1);
        for (j = 0; j<size; i++) {
            uin(&input);
            //process input or store
        }
        while(!alarm);
        sineOff();
        Disable_RTC();
        sleep(2);
    }
}

void Test(int size, NODE* nodes){
    //compare results
}
void Respond(int size, NODE* nodes){
    printu("This is fine");
}

void EXTI9_5_IRQHandler (void)
{
    //PB8: set global to 1, clear reset flag
    if(EXTI->PR&EXTI_PR_PR8) {
        EXTI->PR |= EXTI_PR_PR8;
    }
    //PB9: clear reset flag, set global to 2
    else if (EXTI->PR&EXTI_PR_PR9) {
        EXTI->PR |= EXTI_PR_PR9;
    }
    else
    {
        NVIC_DisableIRQ(EXTI9_5_IRQn);
    }
}


void RTCAlarm_IRQHandler(void)
{
    if((EXTI->PR & EXTI_PR_PR17) == EXTI_PR_PR17)
    {
        EXTI->PR |= EXTI_PR_PR17;
        if ((RTC->CRL & RTC_CRL_ALRF)==RTC_CRL_ALRF){
            RTC->CRL &= ~RTC_CRL_ALRF;
        }
        alarm = 1;
    }
    else
    {
        NVIC_DisableIRQ(RTCAlarm_IRQn);// Disable
    }
}

void led_wigwag(void)
{
    int i=0;
    ledGBSet(BLUE_ON | GREEN_OFF);
    for(i=0; i< 1200000; ++i);
    ledGBTog(BLUE_ON|GREEN_ON);
    for(i=0; i< 1200000; ++i);
    ledGBTog(BLUE_ON|GREEN_ON);
    
}

